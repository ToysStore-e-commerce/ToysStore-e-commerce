package store.toys.ecommerce.exceptions;

public class GlobalExceptionHandler {
}
